package ApostilaCap4;

public class Atividade6 {
    public static void main(String[] args) {
        Conta c1 = new Conta();
        c1.titular = "Abc";
        Data data = new Data();
        c1.dataDeAbertura = data;
        
    }
}
