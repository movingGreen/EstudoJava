public class SomaNumeros {
    public static void main(String[] args) {
        int somaTotal = 0;
        for (int i = 0; i < 1001; i++) {
            somaTotal += i;
        }
        System.out.println(somaTotal);
    }
}
