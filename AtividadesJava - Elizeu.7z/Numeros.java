public class Numeros {
    public static void main(String[] args) {
        for (int i = 150; i < 301; i++) {
            System.out.println(i);
        }
    }
}