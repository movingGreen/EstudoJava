package ApostilaCap5;

public class Data {
    int dia = 10;
    int mes = 10;
    int ano = 2010;

    public String formatada() {
        return this.dia + "/" + this.mes + "/" + this.ano;
    }
}
